#include <string>
class Hello_Class {
	public:
	Hello_Class(int i);
	void print_hello();
	private:
	std::string output_string;
};
